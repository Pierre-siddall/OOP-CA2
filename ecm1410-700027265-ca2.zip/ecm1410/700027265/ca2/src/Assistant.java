/**
 * @author Pierre Siddall
 * This class holds the attributes of an assistant
 * that will be registered in the university's resources.
 * The constructor assigns the following to the class
 *
 * The name of the assistant
 * The email of the assistant
 * */
public class Assistant {
   private String name;
   private String email;

   /**
    * @param name The name of the assistant
    * This method sets the name of the assistant
    * but also checks to see if the name passed is a null value
    * if so the name is set to "Anonymous"*/
   public void setName(String name){
       try{
           this.name=name;
       }catch (NullPointerException e){ // Here if the assistant receives no name the name is set to the default value of "Anonymous"
           this.name="Anonymous";
       }
   }

    /**
     *
     * @return The name of the assistant
     */
   public String getName(){
       return name;
   }

   /**
    * This method sets the assistants email.
    * This is done by using the getter method to get
    * the assistants name and appending the string
    * "@uok.ac.uk" to it.*/
   public void setEmail(){
       this.email=getName()+"@uok.ac.uk";
   }

    /**
     *
     * @return The email of the assistant
     */
   public String getEmail(){
       return email; 
   }

   @Override
    public String toString(){
       return "|"+getName()+"|"+getEmail()+"|";
   }

    /**
     *
     * @param name
     *This method is the constructor method for the Assistant class and it sets the name passed
     * and sets an email for that assistant based on the name given as a parameter.
     */
   public Assistant(String name){
       setName(name);
       setEmail();
   }
}
