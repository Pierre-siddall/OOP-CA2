enum assistantOnShiftStatus{FREE,BUSY}
/**
 * @author Pierre Siddall
 * This class is used to create an shift for a given assistant
 * the constructor assigns the following to the class:
 *
 * An assistant
 * A bookable room
 * A date on which the assistants shift will take place
 * A time at which the assistants shift will take place
 * The formatted working date and time of the shift
 * The assistant on shifts status (FREE or BUSY)
 *
 * */
public class AssistantOnShift {
    private Assistant assistant;
    private BookableRoom bookableRoom;
    private String workingDate;
    private String workingTime;
    private String workingDateTime;
    private assistantOnShiftStatus status;
    private boolean booked=false;

    /**
     * @return  The time at which the assistant will be working*/
    public String getWorkingTime() {
        return workingTime;
    }
    /**
     * @param workingTime The time at which the user wants the assistant to work at
     * Sets the working time for the assistant on shift*/
    public void setWorkingTime(String workingTime) {
        this.workingTime = workingTime;
    }
    /**
     * @return The formatted string including the date and time of the assistants shift*/
    public String getWorkingDateTime() {
        return workingDateTime;
    }
    /**
     * formats the date and time into a string which includes both the date and time and assigns
     * it to workingDateTime*/
    public void setWorkingDateTime() {
        this.workingDateTime = getWorkingDate() + " " + getWorkingTime();
    }

    /**
     * @return The date at which the assistants shift will take place*/
    public String getWorkingDate() {
        return workingDate;
    }

    /**
     * @param workingDate The date at which the user wants the assistants shift to take place
     * sets the date of the assistants shift*/
    public void setWorkingDate(String workingDate) {
        this.workingDate = workingDate;
    }
    /**
     * @return a boolean value to check and see if the assistant is booked*/
    public boolean isBooked() {
        return booked;
    }
    /**
     * @param booked a boolean to describe if the assistant on shift is booked or not
     * sets the value of booked to the boolean passed*/
    public void setBooked(boolean booked) {
        this.booked = booked;
    }
    /**
     * @return The assistant doing the shift */
    public Assistant getAssistant() {
        return assistant;
    }

    /**
     *
     * @param assistant The assistant that is to take the shift
     * Sets the assistant taking the shift
     */
    public void setAssistant(Assistant assistant) {
        this.assistant = assistant;
    }

    /**
     *
     * @param bookableRoom The bookable room that the assistant on shift will use
     */
    public void setBookableRoom(BookableRoom bookableRoom) {
        this.bookableRoom = bookableRoom;
    }

    /**
     *
     * @return the status of the assistant
     */
    public assistantOnShiftStatus getStatus() {
        return status;
    }

    /**
     * This method checks to see if the assistant on shift is booked.
     * If they are the status is set to busy.
     * If not then the status is set to free*/
    public void setStatus() {
        if (isBooked()) {
            this.status = assistantOnShiftStatus.BUSY;
        } else {
            this.status = assistantOnShiftStatus.FREE;
        }
    }
    /**
     * @return  This method returns a boolean value
     * This method checks to see if the user is allowed to create an assistant on shift*/
    public boolean allowedToCreateAssistantOnShift(BookableRoom bookableRoom) {
        return bookableRoom.getRoomCapacity() != bookableRoom.getOccupancy(); //Here the relevant checks are made to see if the user can create an assistant on shift by comparing room capacity and occupancy
    }
    /**
     * @return  This method returns a string containing the email of the assistant assigned */
    public String getAssistantEmail() {
        return getAssistant().getEmail();//Here the assistants email is returned
    }
    /**
     * @return This method returns a string containing the name of the assistant assigned*/
    public String getAssistantName(){
        return getAssistant().getName();// Here the assistants name is returned
    }


    @Override
    public String toString() {
        return "|" + getWorkingDateTime() + "|" + getStatus() + "|" + assistant.getEmail() + "|";
    }

    /**
     *
     * @param assistant
     * @param bookableRoom
     * @param workingDate
     * @param workingTime
     *
     * This method is the classes constructor method
     */
    public AssistantOnShift(Assistant assistant, BookableRoom bookableRoom, String workingDate, String workingTime) {
        if (allowedToCreateAssistantOnShift(bookableRoom)) {
            setAssistant(assistant);
            setBookableRoom(bookableRoom);
            setWorkingDate(workingDate);
            setWorkingTime(workingTime);
            setWorkingDateTime();
            setStatus();
        }
    }
}