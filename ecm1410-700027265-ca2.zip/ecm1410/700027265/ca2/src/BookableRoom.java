enum bookableRoomStatus{EMPTY,AVAILABLE,FULL}

/**
 * @author Pierre Siddall
 * This class is used to create a room which can be
 * booked for a covid test.
 * The constructor assigns the following to the class
 *
 * The room that will be used for the covid test
 * The status of that room (which is initially set to empty)
 * The date in whic hthe room will be used
 * The time the room will be used at
 * The formatted date and time together
 * */
public class BookableRoom {
    private Room room;
    private bookableRoomStatus status;
    private int occupancy=0;
    private String date;
    private String time;
    private String localDateTime;

    /**
     *
     * @return The date on which the bookable room can be booked
     */
    public String getDate() {
        return date;
    }

    /**
     *
     * @param date The date on which the bookable room can be booked
     *  Sets the date on which the bookable room can be booked
     */
    public void setDate(String date) {
        this.date = date;
    }

    /**
     *
     * @return The time at which a bookable room can be booked
     */
    public String getTime() {
        return time;
    }

    /**
     *
     * @param time The time in which the user wants the bookable room to be available for booking
     * Sets the time in which the user wants the bookable room to be available for booking
     */
    public void setTime(String time) {
        this.time = time;
    }

    /**
     *
     * @return The formatted string including the date and time
     */
    public String getLocalDateTime() {
        return localDateTime;
    }

    /**
     * This setter method sets the date and time of the bookable
     * in a format  date+" "+time.However before the date and time
     * is formatted the time is checked to see if the time is within the acceptable range
     * */
    public void setLocalDateTime() {
        if(checkRoomTime(getTime())) {
            this.localDateTime = getDate() + " " + getTime();
        }
    }

    /**
     *
     * @return The occupancy of the bookable room
     */
    public int getOccupancy() {
        return occupancy;
    }

    /**
     * Increments the value of the bookable rooms by 1
     */
    public void setOccupancy() {
        this.occupancy++;
    }

    public Room getRoom() {
        return room;
    }
    /**
     * @return The capacity of the room assigned is returned */
    public int getRoomCapacity(){
        return room.getCapacity();
    }

    /**
     * @return The code of the room assigned is returned
     * */
    public String getRoomCode(){
        return room.getCode();
    }

    /**
     *
     * @param room The room that is going to be made available for a booking
     * Set the value of room to the room that is going to be made available for a booking
     */
    public void setRoom(Room room) {
        this.room = room;
    }

    /**
     *
     * @return The bookable rooms status
     */
    public bookableRoomStatus getStatus() {
        return status;
    }

    /**
     * Here this setter method sets the status of the bookable room by checking
     * the value of its occupancy if the occupancy is zero the room status is set
     * to EMPTY.If not the method then checks if the occupancy is less then the room
     * capacity if so the status of the bookable room is set to AVAILABLE.
     * If not then the method checks to see if the room occupancy is the same as the
     * capacity if so the bookable room is set to FULL*/
    public void setStatus() {
        if (getOccupancy()==0){
            this.status=bookableRoomStatus.EMPTY;
        }else if (getOccupancy()<getRoom().getCapacity()){
            this.status=bookableRoomStatus.AVAILABLE;
        }else if(getOccupancy()==getRoom().getCapacity()){
            this.status=bookableRoomStatus.FULL;
        }
    }

    /**
     * @param inputTime The time that the user has input as the time a bookable room is allowed to be booked at
     * @return A boolean value to indicate whether the time input is within the acceptable range of times
     * This method checks to see if the time at which the room has a booking slot is within the 3 hour time
     * period of 07:00,08:00 or 09:00 in the morning*/
    public boolean checkRoomTime(String inputTime) {
        String[] acceptableValues = {"07:00","08:00","09:00"}; //These are the time values in which a bookable room can be created
        for (String time:acceptableValues){ //This for loop compares the users input time to each of the acceptable times
            if(inputTime.equals(time)){// If the users input equals one of the times
                return true; //The user can use the room time
            }
        }return false;//The user can't use the room time
    }

    @Override
    public String toString(){
        return "|"+getLocalDateTime()+"|"+getStatus()+"|"+getRoomCode()+"|"+getOccupancy()+"|";
    }

    /**
     *
     * @param room
     * @param Date
     * @param time
     *
     * This method is the constructor of the BookableRoom class and sets the values of
     * the parameters by using the appropriate setter methods along with using the setter
     * method of the status to set the status
     */
    public BookableRoom(Room room, String Date,String time){
        setRoom(room);
        setStatus();
        setDate(Date);
        setTime(time);
        setLocalDateTime();
    }
}
