
enum bookingStatus{SCHEDULED,COMPLETED}
/**
 * @author Pierre Siddall
 * This class is used to hold all the information about a booking.
 * The constructor assigns the following to the class:
 *
 * A bookable room that is going to be used
 * An assistant on shift that will perform the covid test
 * A date the test will happen
 * A time the test will happen
 * The formated date and time together
 * The email of the student being tested
 * The status of the booking (which is initially set to SCHEDULED)
 *
 * finally the constructor updates the occupancy and status of the bookable room*/
public class Booking {
    private BookableRoom bookableRoom;
    private AssistantOnShift assistantOnShift;
    private String date;
    private String time;
    private String timeSlot;
    private String studentEmail;
    private bookingStatus status;

    /**
     *
     * @return The date in which the booking is taking place
     */
    public String getDate() {
        return date;
    }

    /**
     *
     * @param date The date input in which the booking is taking place
     * Set the date in which the booking is taking place
     */
    public void setDate(String date) {
        this.date = date;
    }

    /**
     *
     * @return The time in which the booking is taking place
     */
    public String getTime() {
        return time;
    }

    /**
     *
     * @param time The time at which the booking is taking place
     * Sets the time in which the booking is taking place
     */
    public void setTime(String time) {
        this.time = time;
    }

    /**
     *
     * @return The status of the booking
     */
    public bookingStatus getStatus() {
        return status;
    }

    /**
     *
     * @param status The new status of the booking
     * Sets the status of the booking to the new status
     */
    public void setStatus(bookingStatus status) {
        this.status = status;
    }

    /**
     *
     * @return The bookable room being used in the booking
     */
    public BookableRoom getBookableRoom() {
        return bookableRoom;
    }

    /**
     *
     * @param bookableRoom The bookable room that will be used in the booking
     */
    public void setBookableRoom(BookableRoom bookableRoom) {
        this.bookableRoom = bookableRoom;
    }

    /**
     *
     * @return The assistant on shift involved in the booking
     */
    public AssistantOnShift getAssistantOnShift() {
        return assistantOnShift;
    }

    /**
     *
     * @param assistantOnShift The assistant on shift that is involved in the booking
     * Sets the assistant on shift that is involved in the booking
     */
    public void setAssistantOnShift(AssistantOnShift assistantOnShift) {
        this.assistantOnShift = assistantOnShift;
    }

    /**
     *
     * @return The time slot at which the booking is taking place this consists of a date and a time
     */
    public String getTimeSlot() {
        return timeSlot;
    }

    /**
     * Sets the time slot to a formatted string involving
     * the date and the time passed into the booking constructor
     */
    public void setTimeSlot() {
        this.timeSlot = getDate()+" "+getTime(); //Here the date and time are formatted into one string
    }

    /**
     *
     * @return The students email address
     */
    public String getStudentEmail() {
        return studentEmail;
    }

    /**
     *
     * @param studentEmail The email of the student being tested
     * Sets the email of the student being tested
     */
    public void setStudentEmail(String studentEmail) {
        this.studentEmail = studentEmail;
    }
    /**
     * This method is used to update the occupancy and status of the bookable room assigned to
     * the booking using the setter methods for the occupancy and status of a bookable room*/
    public void setOccupancyAndStatusForBookableRoom() { //Here the occupancy of the bookable room is incremented by one and then the relevant checks to set the status are made
        getBookableRoom().setOccupancy();
        getBookableRoom().setStatus();

    }

    @Override
    public String toString(){
        return "|"+getTimeSlot()+"|"+getStatus()+"|"+getAssistantOnShift().getAssistantEmail()+"|"+getBookableRoom().getRoomCode()+"|"+getStudentEmail()+"|";
    }

    /**
     *
     * @param bookableRoom
     * @param assistantOnShift
     * @param date
     * @param time
     * @param studentEmail
     *
     * This method is the constructor of the booking class
     */
    public Booking(BookableRoom bookableRoom, AssistantOnShift assistantOnShift, String date,String time, String studentEmail) {
        if(bookableRoom.getStatus()!=bookableRoomStatus.FULL) {
            setBookableRoom(bookableRoom);
            setAssistantOnShift(assistantOnShift);
            setDate(date);
            setTime(time);
            setTimeSlot();
            setStudentEmail(studentEmail);
            setStatus(bookingStatus.SCHEDULED);
            setOccupancyAndStatusForBookableRoom();
        }
    }
}
