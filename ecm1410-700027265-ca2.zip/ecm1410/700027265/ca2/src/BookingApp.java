import java.util.ArrayList;
/**
 * @author Pierre Siddall
 * This class is the main class of my application
 * The aim of this class is to initialise the nessecary resources
 * in the application and to then load them into the Booking System
 * by calling the booking system class.*/
public class BookingApp {
    /**
     * @return An instance of the UniversityResources class
     * The aim of this method is to initialise the university
     * resources used in the booking system into an instance
     * of UniversityResources*/
    public  static UniversityResources initialiseUniversityResources(){
        Assistant[] assistantsInit={new Assistant("Pedro"),new Assistant("Josiah"), new Assistant("Emily-Jane")}; //Here the university resources are initialised in the form of an array
        Room[] roomsInit={new Room(15),new Room(3),new Room(7)};
        UniversityResources universityResources=new UniversityResources(assistantsInit,roomsInit);
        return universityResources;
    }
    /**
     * @return An ArrayList of BookableRooms
     * The aim of this method is to initialise the bookable
     * rooms used in the booking system into an ArrayList
     * the ArrayList is then returned*/
    public static ArrayList<BookableRoom> initialiseBookableRooms(){
        UniversityResources universityResources=initialiseUniversityResources();
        ArrayList<BookableRoom> bookableRooms=new ArrayList<BookableRoom>();
        bookableRooms.add(new BookableRoom(universityResources.getRooms().get(0),"03/03/2021","07:00")); //Here the bookable rooms are added to an ArrayList of bookable rooms
        bookableRooms.add(new BookableRoom(universityResources.getRooms().get(0),"03/03/2021","08:00"));
        bookableRooms.add(new BookableRoom(universityResources.getRooms().get(0),"03/03/2021","09:00"));
        bookableRooms.add(new BookableRoom(universityResources.getRooms().get(1),"03/03/2021","07:00"));
        bookableRooms.add(new BookableRoom(universityResources.getRooms().get(1),"03/03/2021","08:00"));
        bookableRooms.add(new BookableRoom(universityResources.getRooms().get(1),"03/03/2021","09:00"));
        bookableRooms.add(new BookableRoom(universityResources.getRooms().get(2),"03/03/2021","07:00"));
        bookableRooms.add(new BookableRoom(universityResources.getRooms().get(2),"03/03/2021","08:00"));
        bookableRooms.add(new BookableRoom(universityResources.getRooms().get(2),"03/03/2021","09:00"));
        return bookableRooms;
    }

    /**
     * @return An ArrayList of assistants on shift
     * The aim of this method is to initialise the assistants
     * on shift in the booking system into an ArrayList
     * the ArrayList is then returned*/
    public static ArrayList<AssistantOnShift> initialiseAssistantsOnShift(){
        UniversityResources universityResources=initialiseUniversityResources();
        ArrayList<BookableRoom> bookableRooms=initialiseBookableRooms();
        ArrayList<AssistantOnShift> assistantOnShifts=new ArrayList<AssistantOnShift>();
        assistantOnShifts.add(new AssistantOnShift(universityResources.getAssistants().get(0),bookableRooms.get(0),bookableRooms.get(0).getDate(),bookableRooms.get(0).getTime()));//Here the assistants on shift are added to an ArrayList of assistants on shift
        assistantOnShifts.add(new AssistantOnShift(universityResources.getAssistants().get(0),bookableRooms.get(1),bookableRooms.get(1).getDate(),bookableRooms.get(1).getTime()));
        assistantOnShifts.add(new AssistantOnShift(universityResources.getAssistants().get(1),bookableRooms.get(2),bookableRooms.get(2).getDate(),bookableRooms.get(2).getTime()));
        assistantOnShifts.add(new AssistantOnShift(universityResources.getAssistants().get(1),bookableRooms.get(3),bookableRooms.get(3).getDate(),bookableRooms.get(3).getTime()));
        assistantOnShifts.add(new AssistantOnShift(universityResources.getAssistants().get(2),bookableRooms.get(4),bookableRooms.get(4).getDate(),bookableRooms.get(4).getTime()));
        assistantOnShifts.add(new AssistantOnShift(universityResources.getAssistants().get(2),bookableRooms.get(5),bookableRooms.get(5).getDate(),bookableRooms.get(5).getTime()));
        return assistantOnShifts;
    }

    /**
     * @return An ArrayList of bookings
     * The aim of this method is to initialise the
     * booking already in the booking system into an ArrayList
     * the ArrayList is then returned*/
    public static ArrayList<Booking> initialiseBookings(){
        ArrayList<BookableRoom> bookableRooms=initialiseBookableRooms();
        ArrayList<AssistantOnShift> assistantOnShifts=initialiseAssistantsOnShift();
        ArrayList<Booking> bookings= new ArrayList<Booking>();
        bookings.add(new Booking(bookableRooms.get(0),assistantOnShifts.get(0),bookableRooms.get(0).getDate(),bookableRooms.get(0).getTime(),"ps523@uok.ac.uk"));//Here the bookings are added to an ArrayList of bookings
        bookings.add(new Booking(bookableRooms.get(1),assistantOnShifts.get(0),bookableRooms.get(1).getDate(),bookableRooms.get(1).getTime(),"js976@uok.ac.uk"));
        bookings.add(new Booking(bookableRooms.get(2),assistantOnShifts.get(2),bookableRooms.get(2).getDate(),bookableRooms.get(2).getTime(),"rg342@uok.ac.uk"));
        bookings.add(new Booking(bookableRooms.get(3),assistantOnShifts.get(2),bookableRooms.get(3).getDate(),bookableRooms.get(3).getTime(),"am374@uok.ac.uk"));
        return bookings;
    }

    /**
     * @param args This parameter is to hold any arguments passed to the main method before the runtime of the application
     * This is the main method where the booking application is run*/
    public static void main(String[] args){
        UniversityResources universityResources=initialiseUniversityResources();
        ArrayList<BookableRoom> bookableRooms=initialiseBookableRooms();
        ArrayList<AssistantOnShift> assistantOnShifts=initialiseAssistantsOnShift();
        ArrayList<Booking> bookings=initialiseBookings();
        BookingSystem bookingSystem=new BookingSystem(bookableRooms,assistantOnShifts,bookings,universityResources);
        bookingSystem.showMainMenu();

    }
}