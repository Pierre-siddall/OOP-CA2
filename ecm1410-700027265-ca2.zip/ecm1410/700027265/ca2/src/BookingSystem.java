import java.util.ArrayList;
import java.util.Scanner;
import java.util.Random;

/**
 * @author Pierre Siddall
 * This class is the booking system which implements the main functionality of
 * my application. This class handles the I/O of the application along with the
 * appropriate responses that the system gives.
 */
public class BookingSystem {
    private UniversityResources universityResources;
    private ArrayList<BookableRoom> bookableRooms=new ArrayList<BookableRoom>();
    private ArrayList<AssistantOnShift> assistantsOnShifts=new ArrayList<AssistantOnShift>();
    private ArrayList<Booking>bookings=new ArrayList<Booking>();

    /**
     *
     * @param universityResources The UniversityResources object which holds the universities resources
     * Sets the university resources that the booking system will use
     */
    public void setUniversityResources(UniversityResources universityResources) {
        this.universityResources = universityResources;
    }

    /**
     *
     * @return The UniversityResources object
     */
    public UniversityResources getUniversityResources() {
        return universityResources;
    }

    /**
     *
     * @return The ArrayList of bookable rooms
     */
    public ArrayList<BookableRoom> getBookableRooms() {
        return bookableRooms;
    }

    /**
     *
     * @param bookableRooms This is the initial ArrayList containing bookable rooms
     * Sets the value of bookableRooms to the ArrayList given as a parameter
     */
    public void setBookableRooms(ArrayList<BookableRoom> bookableRooms) {
        this.bookableRooms = bookableRooms;
    }

    /**
     *
     * @return The ArrayList of assistants on shifts
     */
    public ArrayList<AssistantOnShift> getAssistantsOnShifts() {
        return assistantsOnShifts;
    }

    /**
     *
     * @param assistantsOnShifts The initial ArrayList of assistants taking shifts
     * Sets the ArrayList of assistants taking shifts
     */
    public void setAssistantsOnShifts(ArrayList<AssistantOnShift> assistantsOnShifts) {
        this.assistantsOnShifts = assistantsOnShifts;
    }

    /**
     *
     * @return  The ArrayList of Bookings
     */
    public ArrayList<Booking> getBookings() {
        return bookings;
    }

    /**
     *
     * @param bookings The ArrayList of initial bookings in the system
     */
    public void setBookings(ArrayList<Booking> bookings) {
        this.bookings = bookings;
    }
    /**
     * This method handles the adding of bookable rooms to the booking system*/
    public void addToBookableRooms(){
        String newline="\n\r";
        System.out.println(newline);
        System.out.println(newline);
        System.out.println(newline);
        System.out.println("University of Knowledge-COVID test");
        System.out.println(newline);
        System.out.println("Adding bookable room");
        System.out.println(newline);
        listRooms();
        System.out.println("The sequential ID listed to a room a date (dd/mm/yyyy), and a time(HH:MM),"); //PLEASE REMEMBER THIS
        System.out.println("separated by a white space");
        System.out.println("0.Back to main menu");
        System.out.println("-1. Quit application");
        System.out.println(newline);
        allowAddBookableRoomsInput(); // Here the code allows for the user to give input
    }
    /**
     * This method lists all the rooms in the university resources array in a string format*/
    public void listRooms(){
        for(Room room: getUniversityResources().getRooms()){
            System.out.println(room.toString());
        }
    }

    /**
     *
     * @param userInput This is the input that the user has provided into the booking system
     * This method deals with adding a bookable room if the given input is the correct format.
     */
    public void addBookableRoomSuccess(String userInput){
        try {
            String newline = "\n\r";
            String roomID = userInput.substring(0,userInput.indexOf(" "));//Here the users input is divided into substrings to be parsed into the constructor
            String date = userInput.substring(userInput.indexOf(" ")+1,userInput.indexOf(" ")+11);
            String time = userInput.substring(userInput.indexOf(" ")+12,userInput.indexOf(" ")+17);
            BookableRoom bookableRoomToBeAdded=new BookableRoom(getUniversityResources().getRoomWithSequentialId(roomID),date,time);
            System.out.println(bookableRoomToBeAdded.toString());
            getBookableRooms().add(bookableRoomToBeAdded);
            System.out.println(newline);
            System.out.println(newline);
            System.out.println(newline);
            System.out.println("Bookable Room added successfully");
            System.out.println(bookableRoomToBeAdded.toString());
            System.out.println("Please enter one of the following");
            System.out.println(newline);
            System.out.println("The sequential ID listed to a room, a date(dd/mm/yyyy), and a time(HH:MM)");
            System.out.println("separated by a white space");
            System.out.println("0.Back to main menu");
            System.out.println("-1.Quit application");
            System.out.println(newline);
            allowAddBookableRoomsInput();
        }catch (RuntimeException e){
            addBookableRoomFail();
        }
    }
    /**
     * This method handles the error messages given if the user either provides the wrong input or
     * an unexpected error occurs during the runtime of the program with the appropriate messages
     * for the failure of an addition of a bookable room */
    public void addBookableRoomFail(){
        String newline="\n\r";
        System.out.println(newline);
        System.out.println(newline);
        System.out.println(newline);
        System.out.println("Error");
        System.out.println("The data you have input for the bookable room is invalid");
        System.out.println("Please, enter one of the following");
        System.out.println(newline);
        System.out.println("The sequential ID listed to a room, a date(dd/mm/yyyy), and a time(HH:MM)");
        System.out.println("separated by a white space");
        System.out.println("0.Back to main menu");
        System.out.println("-1.Quit application");
        System.out.println(newline);
        allowAddBookableRoomsInput();
    }
    /**
     * This method allows the user to provide input to the system
     * and gives the appropriate success and failure messages when the user
     * tries to add a bookable room */
    public void allowAddBookableRoomsInput(){
        try {
            Scanner scanner = new Scanner(System.in);
            String choice = scanner.nextLine();
            if (choice.equals("-1")) {
                System.exit(0);
            } else if (choice.equals("0")) {
                showMainMenu();
            } else if (choice != "0" && choice != "-1") {
                addBookableRoomSuccess(choice);//  In most of the input methods (minus the methods which only require the listing of things) users input is assumed to be valid
            }// If an error is found along the way the system executes the failure method
        }catch (RuntimeException e){
                addBookingFail(); 
            }
    }
    /**
     * This method handles the removal of bookable rooms from the booking system*/
    public void removeFromBookableRooms(){
        String newline="\n\r";
        System.out.println(newline);
        System.out.println(newline);
        System.out.println(newline);
        System.out.println("University of Knowledge-COVID test");
        System.out.println(newline);
        listEmptyBookableRooms();
        System.out.println("Removing bookable room");
        System.out.println(newline);
        System.out.println("Please,enter one of the following");
        System.out.println(newline);
        System.out.println("The sequential ID to select the bookable room to be removed ");
        System.out.println("0.Back to main menu");
        System.out.println("-1.Quit application");
        System.out.println(newline);
        allowRemoveBookableRoomsInput();
    }

    /**
     * This method lists all the empty bookable rooms in a string format*/
    public void listEmptyBookableRooms(){
        for (BookableRoom bookableRoom:getBookableRooms()){
            if(bookableRoom.getStatus()==bookableRoomStatus.EMPTY){ //Here the status of a bookable room is checked to see if it's empty
                System.out.println(bookableRoom.toString());
            }
        }
    }

    public BookableRoom getBookableRoomTobeRemoved(String userInput){
        for (BookableRoom bookableRoom:getBookableRooms()){
            String checkId=bookableRoom.getRoomCode();
            if(checkId.equals(userInput)){// Here the room code the user input is checked to see if it equals a room code of a bookable room
                return bookableRoom;
            }
        }return null;
    }

    /**
     *
     * @param userInput This is the input that the user has provided into the booking system
     * This method deals with removing a bookable room if the given input is the correct format.
     */
    public void removeBookableRoomSuccess(String userInput){
        String newline="\n\r";
        try{
            BookableRoom bookableRoomToBeRemoved=getBookableRoomTobeRemoved(userInput);
            if (bookableRoomToBeRemoved.getStatus()==bookableRoomStatus.EMPTY) { //Here the relevant check is made to see if the user can actually remove a bookable room
                getBookableRooms().remove(bookableRoomToBeRemoved);
                System.out.println(newline);
                System.out.println(newline);
                System.out.println(newline);
                System.out.println("Bookable Room removed successfully");
                System.out.println(bookableRoomToBeRemoved.toString());
                System.out.println("Please enter one of the following: ");
                System.out.println(newline);
                System.out.println("The sequential ID to select the bookable room to be removed");
                System.out.println("0.Back to main menu");
                System.out.println("-1.Quit application");
                System.out.println(newline);
                allowRemoveBookableRoomsInput();
            }
            }catch (RuntimeException e) {
            removeBookableRoomFail();
        }
        }
    /**
     * This method handles the error messages given if the user either provides the wrong input or
     * an unexpected error occurs during the runtime of the program with the appropriate messages
     * for the failure of a removal of a bookable room*/
    public void removeBookableRoomFail(){
        String newline="\n\r";
        System.out.println(newline);
        System.out.println(newline);
        System.out.println(newline);
        System.out.println("Error!");
        System.out.println("The data input to remove the bookable room is invalid");
        System.out.println("Please enter one of the following:");
        System.out.println(newline);
        System.out.println("0.Back to main menu");
        System.out.println("-1.Quit application");
        System.out.println(newline);
        allowRemoveBookableRoomsInput();
    }

    /**
     * This method allows the user to provide input to the system
     * and gives the appropriate success and failure messages when the user
     * tries to remove a bookable room */
    public void allowRemoveBookableRoomsInput() {
        try {
            Scanner scanner = new Scanner(System.in);
            String choice = scanner.nextLine();
            if (choice.equals("-1")) {
                System.exit(0);
            } else if (choice.equals("0")) {
                showMainMenu();
            }else if (choice!="0" && choice!="-1"){
                removeBookableRoomSuccess(choice);
            }
        } catch (RuntimeException e) {
            System.out.println("An error which has not been accounted for has happened");
            removeBookableRoomFail();
        }
    }

    /**
     * This method lists all the bookable rooms in a string format*/
    public void listBookableRooms(){
        for (BookableRoom bookableRoom: getBookableRooms()){
            System.out.println(bookableRoom.toString());
        }
    }
    /**
     * This method handles the listing of bookable rooms from the booking system*/
    public void showBookableRooms(){
        String newline="\n\r";
        System.out.println(newline);
        System.out.println(newline);
        System.out.println(newline);
        System.out.println("University of Knowledge-COVID test");
        System.out.println(newline);
        listBookableRooms();
        System.out.println("0. Back to main menu");
        System.out.println("-1 Quit application");
        allowShowBookableRoomsInput();
    }
    /**
     * This method allows the user to provide input to the system
     * and redirects the user or terminates the program if 0 or -1 are
     * input respectively*/
    public void allowShowBookableRoomsInput(){
        try{
            Scanner scanner=new Scanner(System.in);
            String choice=scanner.nextLine();
            if (choice.equals("-1")){ //Here there is no option of success or fail as the user doesn't need to provide input
                System.exit(0);
            }else if(choice.equals("0")){
                showMainMenu();}

        }catch (RuntimeException e){
            System.out.println("An error which has not been accounted for has happened");
        }
    }
    /**
     * This method handles the adding of an assistants shift to the booking system*/
    public void addToAssistantsOnShift(){
        String newline="\n\r";
        System.out.println(newline);
        System.out.println(newline);
        System.out.println(newline);
        System.out.println("University of Knowledge-COVID test");
        System.out.println(newline);
        System.out.println("Adding assistant on shift");
        System.out.println(newline);
        listAssistants();
        System.out.println("Please, enter one of the following:");
        System.out.println(newline);
        System.out.println("The sequential ID of an assistant and date(dd/mm/yyyy), separated by a white space.");
        System.out.println("0. Back to main menu");
        System.out.println("-1 Quit application.");
        allowAddAssistantsOnShiftInput();
    }

    /**
     * This method lists all the assistants in the university resources array in a string format*/
    public void listAssistants(){
        for(Assistant assistant:getUniversityResources().getAssistants()){
            System.out.println(assistant.toString());
        }
    }

    /**
     *
     * @param userInput This is the input that the user has provided into the booking system
     * This method deals with adding a assistant on shift if the given input is the correct format.
     */
    public void addAssistantsOnShiftSuccess(String userInput){
        try {
            Random rand = new Random();
            String newline = "\n\r";
            String name = userInput.substring(0, userInput.indexOf(" "));//Again here the users input is divided into a set of substrings to be parsed into a constructor
            String date = userInput.substring(userInput.indexOf(" ") + 1, userInput.indexOf(" ") + 11);
            Assistant assistantToBePutOnShift = getAssistantToBePutOnShift(name);
            int randomBookableRoomIndex = rand.nextInt(getBookableRooms().size());
            AssistantOnShift assistantOnShiftToBeAdded7 = new AssistantOnShift(assistantToBePutOnShift, getBookableRooms().get(randomBookableRoomIndex), date, "7:00");
            AssistantOnShift assistantOnShiftToBeAdded8 = new AssistantOnShift(assistantToBePutOnShift, getBookableRooms().get(randomBookableRoomIndex), date, "8:00");
            AssistantOnShift assistantOnShiftToBeAdded9 = new AssistantOnShift(assistantToBePutOnShift, getBookableRooms().get(randomBookableRoomIndex), date, "9:00");

            getAssistantsOnShifts().add(assistantOnShiftToBeAdded7);//Here the assistants shifts are added
            getAssistantsOnShifts().add(assistantOnShiftToBeAdded8);
            getAssistantsOnShifts().add(assistantOnShiftToBeAdded9);


            System.out.println(newline);
            System.out.println(newline);
            System.out.println(newline);
            System.out.println("Assistant added on shift successfully");
            System.out.println(assistantOnShiftToBeAdded7.toString());
            System.out.println(assistantOnShiftToBeAdded8.toString());
            System.out.println(assistantOnShiftToBeAdded9.toString());
            System.out.println("Please enter one of the following");
            System.out.println(newline);
            System.out.println("The sequential ID of an assistant and date (dd/mm/yyyy), separated by a white space");
            System.out.println("0.Back to main menu");
            System.out.println("-1.Quit application");
            System.out.println(newline);
            allowAddAssistantsOnShiftInput();
        }catch (RuntimeException e){
            addAssistantsOnShiftFail();
        }
    }

    /**
     * This method handles the error messages given if the user either provides the wrong input or
     * an unexpected error occurs during the runtime of the program with the appropriate messages
     * for the failure of an addition of a assistant on shift */
    public void addAssistantsOnShiftFail(){
        String newline="\n\r";
        System.out.println(newline);
        System.out.println(newline);
        System.out.println(newline);
        System.out.println("Error!");
        System.out.println("An invalid data type to add an assistant on shift has been input");
        System.out.println("Please enter one of the following:");
        System.out.println(newline);
        System.out.println("The sequential ID of assistant and date(dd/mm/yyyy), separated by a white space.");
        System.out.println("0.Back to main menu");
        System.out.println("-1.Quit application");
        System.out.println(newline);
        allowAddAssistantsOnShiftInput();
    }

    /**
     *
     * @param searchName The name of the assistant to be put on a shift
     * @return either the correct assistant or null if the assistant is not found
     *
     * This method searches for an assistant with a given name
     */
    public Assistant getAssistantToBePutOnShift(String searchName){
        for(Assistant assistant:getUniversityResources().getAssistants()){
            if(searchName.equals(assistant.getName())){//Here the search name is searched for by iterating through the names of assistants in university resources
                return assistant;
            }
        }return null;
    }

    /**
     * This method allows the user to provide input to the system
     * and gives the appropriate success and failure messages when the user
     * tries to add an assistant on Shift*/
    public void allowAddAssistantsOnShiftInput(){
        try{
            Scanner scanner=new Scanner(System.in);
            String choice=scanner.nextLine();
            if (choice.equals("-1")){
                System.exit(0);
            }else if(choice.equals("0")){
                showMainMenu();
            }else if (choice!="0" && choice!="-1"){
                addAssistantsOnShiftSuccess(choice);
            }
        }catch (RuntimeException e){
            System.out.println("An error which has not been accounted for has happened");
            addAssistantsOnShiftFail();
        }
    }
    /**
     * This method handles the removal of an assistant on shift from the booking system*/
    public void removeFromAssistantsOnShift(){
        String newline="\n\r";
        System.out.println(newline);
        System.out.println(newline);
        System.out.println(newline);
        System.out.println("University  of Knowledge-COVID test");
        System.out.println(newline);
        listFreeAssistantsOnShift();
        System.out.println("Removing assistant on shift");
        System.out.println(newline);
        System.out.println("Please enter one of the following");
        System.out.println(newline);
        System.out.println("The sequential ID to select the assistant on shift to be removed");
        System.out.println("0.Back to main menu.");
        System.out.println("-1. Quit application");
        System.out.println(newline);
        allowRemoveAssistantsOnShiftInput();
    }

    /**
     * This method lists all the free assistants on shift in a string format*/
    public void listFreeAssistantsOnShift(){
        for (AssistantOnShift assistantOnShift:getAssistantsOnShifts()){
            if(assistantOnShift.getStatus()==assistantOnShiftStatus.FREE){ //Here the statuses of assistants on shifts are checked to list the assistants on shifts that are free
                System.out.println(assistantOnShift.toString());
            }
        }
    }

    /**
     *
     * @param userInput This is the input that the user has provided into the booking system
     * This method deals with removal of an assistant on shift if the given input is the correct format.
     */
    public void removeAssistantsOnShiftSuccess(String userInput){
        try {
            String newline = "\n\r";
            AssistantOnShift assistantOnShiftToBeRemoved = getAssistantOnShiftToBeRemoved(userInput);
            getAssistantsOnShifts().remove(assistantOnShiftToBeRemoved); //Here the designated assistant on shift to be removed is removed
            System.out.println(newline);
            System.out.println(newline);
            System.out.println(newline);
            System.out.println("Assistant on Shift removed successfully:");
            System.out.println(assistantOnShiftToBeRemoved.toString());
            System.out.println("Please enter one of the following:");
            System.out.println(newline);
            System.out.println("The sequential ID to select the assistant on shift to be removed");
            System.out.println("0.Back to main menu.");
            System.out.println("-1.Quit application.");
            System.out.println(newline);
            allowRemoveAssistantsOnShiftInput();
        }catch (RuntimeException e){
            removeAssistantOnShiftFail();
        }
    }

    /**
     * This method handles the error messages given if the user either provides the wrong input or
     * an unexpected error occurs during the runtime of the program with the appropriate messages
     * for the failure of a removal of an assistant on shift*/
    public void removeAssistantOnShiftFail(){
        String newline="\n\r";
        System.out.println(newline);
        System.out.println(newline);
        System.out.println(newline);
        System.out.println("Error!");
        System.out.println("The format of the assistant on shift to be removed is invalid");
        System.out.println("Please enter one of the following:");
        System.out.println(newline);
        System.out.println("The sequential ID to select the assistant on shift to be removed");
        System.out.println("0.Back to main menu.");
        System.out.println("-1.Quit application.");
        System.out.println(newline);
        allowRemoveAssistantsOnShiftInput();
    }

    /**
     *
     * @param searchId The name of the assistant on shift to be removed
     * @return either the correct assistant on shift or null if the assistant on shift is not found
     *
     * This method searches for an assistant on shift with a given name
     */
    public AssistantOnShift getAssistantOnShiftToBeRemoved(String searchId){
        for(AssistantOnShift assistantOnShift:getAssistantsOnShifts()){
            if(searchId.equals(assistantOnShift.getAssistantName())){
                return assistantOnShift;
            }
        }return null;
    }

    /**
     * This method allows the user to provide input to the system
     * and gives the appropriate success and failure messages when the user
     * tries to remove an assistant on shift */
    public void allowRemoveAssistantsOnShiftInput(){
        try{
            Scanner scanner=new Scanner(System.in);
            String choice=scanner.nextLine();
            if (choice.equals("-1")){
                System.exit(0);
            }else if(choice.equals("0")){
                showMainMenu();
            }else if(choice!="0" && choice!="-1"){
                removeAssistantsOnShiftSuccess(choice);
            }
        }catch (RuntimeException e){
            System.out.println("An error which has not been accounted for has happened");
            removeAssistantOnShiftFail();
        }
    }
    /**
     * This method handles the listing of assistants on shift from the booking system*/
    public void showAssistantsOnShift(){
        String newline="\n\r";
        System.out.println(newline);
        System.out.println(newline);
        System.out.println(newline);
        System.out.println("University of Knowledge-COVID test");
        System.out.println(newline);
        listAssistantsOnShift();
        System.out.println("0.back to main application");
        System.out.println("-1.Quit application");
        System.out.println(newline);
    }

    /**
     * This method lists all the assistants on shift in a string format*/
    public void listAssistantsOnShift(){
        for (AssistantOnShift assistantOnShift: getAssistantsOnShifts()){
            System.out.println(assistantOnShift.toString());
        }
    }

    /**
     * This method handles the adding of bookings to the booking system*/
    public void addToBookings(){
        String newline="\n\r";
        System.out.println(newline);
        System.out.println(newline);
        System.out.println(newline);
        System.out.println("University of Knowledge-COVID test");
        System.out.println(newline);
        System.out.println("Adding booking (appointment for a COVID test) to the system");
        System.out.println(newline);
        listBookableRoomsTimeSlot();
        System.out.println(newline);
        System.out.println("Please enter one of the following:");
        System.out.println(newline);
        System.out.println("The sequential ID of an available time-slot and the student email, separated by a white space.");
        System.out.println("0.Back to main menu");
        System.out.println("-1. Quit application");
        System.out.println(newline);
        allowAddBookingInput();
    }

    /**
     * This method lists all the bookable rooms time slots in a string format*/
    public void listBookableRoomsTimeSlot(){
        for(BookableRoom bookableRoom:getBookableRooms()){
            System.out.println(bookableRoom.getRoomCode()+" "+bookableRoom.getLocalDateTime());
        }
    }

    /**
     *
     * @param userInput This is the input that the user has provided into the booking system
     * This method deals with adding of a booking if the given input is the correct format.
     */
    public void addBookingSuccess(String userInput){
        try {
            String newline = "\n\r";
            Random rand = new Random();
            String sequentialId = userInput.substring(0,userInput.indexOf(" "));//Here the input is also divided into a list of substrings to be parsed
            String studentEmail = userInput.substring(userInput.indexOf(" ")+1,userInput.indexOf(" ")+16);
            int randomAssistantOnShiftIndex = rand.nextInt(getAssistantsOnShifts().size());//Here a random number is generated so that a random assistant can be assigned to the booking
            AssistantOnShift assistantInvolved = getAssistantsOnShifts().get(randomAssistantOnShiftIndex);
            BookableRoom bookableRoomInvolved=getBookableRoomWithSequentialId(sequentialId);
            Booking bookingToBeAdded = new Booking(bookableRoomInvolved,assistantInvolved,bookableRoomInvolved.getDate(),bookableRoomInvolved.getTime(),studentEmail);
            assistantInvolved.setBooked(true);
            assistantInvolved.setStatus();
            getBookings().add(bookingToBeAdded);
            System.out.println(newline);
            System.out.println(newline);
            System.out.println(newline);
            System.out.println("Booking added successfully");
            System.out.println(bookingToBeAdded.toString());
            System.out.println(newline);
            listBookableRoomsTimeSlot();
            System.out.println(newline);
            System.out.println("Please enter one of the following:");
            System.out.println(newline);
            System.out.println("The sequential ID of an available time-slot and the student email, separated by a white space.");
            System.out.println("0.Back to main menu");
            System.out.println("-1.Quit application");
            System.out.println(newline);
            allowAddBookingInput();
        }catch (RuntimeException e){
            addBookingFail();
        }
    }

    /**
     * This method handles the error messages given if the user either provides the wrong input or
     * an unexpected error occurs during the runtime of the program with the appropriate messages
     * for the failure of an addition of a booking */
    public void addBookingFail(){
        String newline="\n\r";
        System.out.println(newline);
        System.out.println(newline);
        System.out.println(newline);
        System.out.println("Error!");
        System.out.println("You have input a booking with the invalid format");
        System.out.println(newline);
        System.out.println("Please enter one of the following:");
        System.out.println(newline);
        System.out.println("The sequential ID of an available time-slot and the student email, separated by a white space.");
        System.out.println("0.Back to main menu");
        System.out.println("-1.Quit application");
        System.out.println(newline);
        allowAddBookingInput();
    }

    /**
     *
     * @param sequentialId The room code of the bookable room
     * @return either the correct bookable room or null if the bookable room is not found
     *
     * This method searches for a bookable room with a given code
     */
    public BookableRoom getBookableRoomWithSequentialId(String sequentialId){
        for(BookableRoom bookableRoom:getBookableRooms()){
            if(sequentialId.equals(bookableRoom.getRoomCode())){
                return bookableRoom;
            }
        }return null;
    }

    /**
     * This method allows the user to provide input to the system
     * and gives the appropriate success and failure messages when the user
     * tries to add a booking*/
    public void allowAddBookingInput(){
        try{
            Scanner scanner=new Scanner(System.in);
            String choice=scanner.nextLine();
            if (choice.equals("-1")){
                System.exit(0);
            }else if(choice.equals("0")){
                showMainMenu();
            }else if (choice!="0"&& choice!="-1"){
                addBookingSuccess(choice);
            }
        }catch (RuntimeException e){
            System.out.println("An error which has not been accounted for has happened");
            addBookingFail();
        }
    }

    /**
     * This method handles the removal of bookings from the booking system*/
    public void removeFromBookings(){
        String newline="\n\r";
        System.out.println(newline);
        System.out.println(newline);
        System.out.println(newline);
        System.out.println("University of knowledge-COVID test");
        System.out.println(newline);
        listScheduledBookings();
        System.out.println("Remove booking from the system");
        System.out.println(newline);
        System.out.println("Please enter one of the following");
        System.out.println(newline);
        System.out.println("The sequential ID to select the booking to be removed from the listed bookings above");
        System.out.println("0. Back to main menu");
        System.out.println("-1. Quit application");
        System.out.println(newline);
        allowRemoveBookingInput();
    }

    /**
     *
     * @param userInput This is the input that the user has provided into the booking system
     * This method deals with removal of a booking if the given input is the correct format.
     */
    public void removeBookingSuccess(String userInput) {

        String newline = "\n\r";
        Booking bookingToBeRemoved = getBookingWithSequentialId(userInput);
        if (bookingToBeRemoved.getStatus() != bookingStatus.COMPLETED) { //Here the relevant check is made to see if the booking can actually be removed
            try {
                bookings.remove(bookingToBeRemoved);
                System.out.println(newline);
                System.out.println(newline);
                System.out.println(newline);
                System.out.println("Booking removed successfully");
                System.out.println(bookingToBeRemoved.toString());
                System.out.println("Please enter one of the following");
                System.out.println(newline);
                System.out.println("The sequential ID to select the booking to be removed from the listed bookings above");
                System.out.println("0. Back to main menu");
                System.out.println("-1. Quit application");
                System.out.println(newline);
                allowRemoveBookingInput();
            } catch (RuntimeException e) {
                removeBookingFail();
            }
        }
    }

    /**
     * This method handles the error messages given if the user either provides the wrong input or
     * an unexpected error occurs during the runtime of the program with the appropriate messages
     * for the failure of a removal of a booking*/
    public void removeBookingFail(){
        String newline="\n\r";
        System.out.println(newline);
        System.out.println(newline);
        System.out.println(newline);
        System.out.println("Error!");
        System.out.println("The format of the booking that you have entered is invalid");
        System.out.println(newline);
        System.out.println("Please enter one of the following");
        System.out.println(newline);
        System.out.println("The sequential ID to select the booking to be removed from the listed bookings above");
        System.out.println("0. Back to main menu");
        System.out.println("-1. Quit application");
        System.out.println(newline);
        allowRemoveBookingInput();
    }

    /**
     *
     * @param userInput The room code of the booking
     * @return either the correct booking or null if the booking is not found
     *
     * This method searches for a booking with a given room code
     */
    public Booking getBookingWithSequentialId(String userInput){
        for (Booking booking: getBookings()){
            if(booking.getBookableRoom().getRoomCode().equals(userInput)){//Here the user input is checked to see if the room code is a room code in the bookable rooms array
                return booking;
            }
        }return null;
    }

    /**
     * This method allows the user to provide input to the system
     * and gives the appropriate success and failure messages when the user
     * tries to remove a booking*/
    public void allowRemoveBookingInput(){
        try{
            Scanner scanner=new Scanner(System.in);
            String choice=scanner.nextLine();
            if (choice.equals("-1")){
                System.exit(0);
            }else if(choice.equals("0")){
                showMainMenu();
            }else if (choice!="0" && choice!="-1"){
                removeBookingSuccess(choice);
            }
        }catch (RuntimeException e){
            System.out.println("An error which has not been accounted for has happened");
            removeBookingFail();
        }
    }

    /**
     * This method handles the listing of bookings from the booking system*/
    public void showBookings(){
        String newline="\n\r";
        System.out.println(newline);
        System.out.println(newline);
        System.out.println(newline);
        System.out.println("University of Knowledge-COVID test");
        System.out.println(newline);
        System.out.println("Select which booking to list:");
        System.out.println("1.All");
        System.out.println("2.Only booking status: SCHEDULED");
        System.out.println("3.Only booking status:COMPLETED");
        System.out.println("0.Back to main menu");
        System.out.println("-1 Quit application");
        System.out.println(newline);
        allowShowBookingInput();
    }

    /**
     * This method lists all the bookings in a string format*/
    public void listAllBookings(){
        for (Booking booking:getBookings()){
            System.out.println(booking.toString());
        }
    }

    /**
     * This method lists all the scheduled bookings in a string format*/
    public void listScheduledBookings(){
        for (Booking booking:getBookings()){
            if(booking.getStatus()==bookingStatus.SCHEDULED) {//Here the relevant check is made to see if the booking has a scheduled status
                System.out.println(booking.toString());
            }
        }
    }

    /**
     * This method lists all the completed bookings in a string format*/
    public void listCompletedBookings(){
        for (Booking booking:getBookings()){
            if(booking.getStatus()==bookingStatus.COMPLETED) {//Here the relevant check is made to see if the booking has a completed status
                System.out.println(booking.toString());
            }
        }
    }

    /**
     * This method allows the user to provide input to the system
     * and gives the appropriate listings according to the input the user gave*/
    public void allowShowBookingInput(){
        try{
            Scanner scanner=new Scanner(System.in);
            String choice=scanner.nextLine();
            if (choice.equals("-1")){
                System.exit(0);
            }else if(choice.equals("0")){//Here as there are more options on the listing of bookings more inputs have been accounted for and produce the correct screen
                showMainMenu();
            }else if (choice.equals("1")){
                listAllBookings();
            }else if(choice.equals("2")){
                listScheduledBookings();
            }else if(choice.equals("3")){
                listCompletedBookings();
            }
        }catch (RuntimeException e){
            System.out.println("An error which has not been accounted for has happened");
        }
    }

    /**
     * This method handles the conclusion of bookings in the booking system*/
    public void concludeBooking(){
        String newline="\n\r";
        System.out.println(newline);
        System.out.println(newline);
        System.out.println(newline);
        System.out.println("University of Knowledge-COVID Test");
        System.out.println(newline);
        listScheduledBookings();
        System.out.println("Conclude booking");
        System.out.println(newline);
        System.out.println("Please enter one of the following");
        System.out.println(newline);
        System.out.println("The sequential ID to select the booking to be completed");
        System.out.println("0.Back to main menu");
        System.out.println("-1 Quit application");
        System.out.println(newline);
        allowForConcludeBookingInput();
    }

    /**
     *
     * @param userInput This is the input that the user has provided into the booking system
     * This method deals with the conclusion of a booking if the given input is the correct format.
     */
    public void concludeBookingSuccess(String userInput){
        try {
            String newline = "\n\r";
            Booking bookingToBeConcluded = getBookingWithSequentialId(userInput);
            bookingToBeConcluded.setStatus(bookingStatus.COMPLETED);//Here the status of the booking is set to completed
            System.out.println(newline);
            System.out.println(newline);
            System.out.println(newline);
            System.out.println("Booking completed successfully");
            System.out.println(bookingToBeConcluded.toString());
            System.out.println("Please enter one of the following");
            System.out.println(newline);
            System.out.println("The sequential ID to select the booking to be completed");
            System.out.println("0.Back to main menu");
            System.out.println("-1 Quit application");
            System.out.println(newline);
            allowForConcludeBookingInput();
        }catch (RuntimeException e){
            concludeBookingFail();
        }

    }

    /**
     * This method handles the error messages given if the user either provides the wrong input or
     * an unexpected error occurs during the runtime of the program with the appropriate messages
     * for the failure of the conclusion of a booking*/
    public void concludeBookingFail(){
        String newline="\n\r";
        System.out.println(newline);
        System.out.println(newline);
        System.out.println(newline);
        System.out.println("Error!");
        System.out.println("You haven't entered a valid sequential ID of a booking");
        System.out.println("Please enter one of the following");
        System.out.println(newline);
        System.out.println("The sequential ID to select the booking to be completed");
        System.out.println("0.Back to main menu");
        System.out.println("-1 Quit application");
        System.out.println(newline);
        allowForConcludeBookingInput();
    }
    /**
     * This method allows the user to provide input to the system
     * and gives the appropriate success and failure messages when the user
     * tries to conclude a booking */
    public void allowForConcludeBookingInput(){
        try{
            Scanner scanner=new Scanner(System.in);
            String choice=scanner.nextLine();
            if (choice.equals("-1")){
                System.exit(0);
            }else if(choice.equals("0")){
                showMainMenu();
            }else if (choice!="0" && choice!="-1"){
                concludeBookingSuccess(choice);
            }
        }catch (RuntimeException e){
            System.out.println("An error which has not been accounted for has happened");
            concludeBookingFail();
        }
    }

    /**
     * This method handles the displaying of the main menu*/
    public void showMainMenu() { //Here the main menu and its options are displayed
        String newline = "\n\r";
        System.out.println(newline);
        System.out.println(newline);
        System.out.println(newline);
        System.out.println("University of Knowledge-COVID test");
        System.out.println(newline);
        System.out.println("Manage Bookings");
        System.out.println("Please enter the number to select your option");
        System.out.println(newline);
        System.out.println("To manage Bookable Rooms");
        System.out.println("           1.List");
        System.out.println("           2.add");
        System.out.println("           3.remove");
        System.out.println("To manage Assistants on shift");
        System.out.println("           4.List");
        System.out.println("           5.add");
        System.out.println("           6.remove");
        System.out.println("To manage Bookings");
        System.out.println("           7.List");
        System.out.println("           8.add");
        System.out.println("           9.remove");
        System.out.println("           10.conclude");
        System.out.println("After selecting one of the options above,you will you will be presented other screens");
        System.out.println("If you press 0 you will be able to this main menu");
        System.out.println("Press -1 (or ctrl+c) to quit this application");
        System.out.println(newline);
        allowForMainMenuInput();

    }

    /**
     * This method allows the user to provide input to the system
     * and gives the appropriate menu (from the main menu to the users choice)
     * using a switch case statement */
    public void allowForMainMenuInput(){
        try{
            Scanner scanner=new Scanner(System.in);
            String choice=scanner.nextLine();
            switch (choice) {//Here a switch case statement is used to handle all the different inputs from the main menu and by default if non of the choices have been chosen sends you back to the main menu again
                case "-1":
                    System.exit(0);
                    break;
                case "1":
                    showBookableRooms();
                    break;
                case "2":
                    addToBookableRooms();
                    break;
                case "3":
                    removeFromBookableRooms();
                    break;
                case "4":
                    showAssistantsOnShift();
                    break;
                case "5":
                    addToAssistantsOnShift();
                    break;
                case "6":
                    removeFromAssistantsOnShift();
                    break;
                case "7":
                    showBookings();
                    break;
                case "8":
                    addToBookings();
                    break;
                case "9":
                    removeFromBookings();
                    break;
                case "10":
                    concludeBooking();
                    break;
                default:
                    showMainMenu();
                    break;
            }
        }catch (RuntimeException e){
            System.out.println("An error which has not been accounted for has happened");
        }
    }

    /**
     *
     * @param bookableRooms
     * @param assistantsOnShifts
     * @param bookings
     * @param universityResources
     *
     * This method is the class constructor and sets the values given by the parameters
     * with the appropriate setter methods
     */
    public BookingSystem(ArrayList<BookableRoom> bookableRooms, ArrayList<AssistantOnShift> assistantsOnShifts, ArrayList<Booking> bookings,UniversityResources universityResources) {
        setUniversityResources(universityResources);
        setBookableRooms(bookableRooms);
        setAssistantsOnShifts(assistantsOnShifts);
        setBookings(bookings);

    }
}