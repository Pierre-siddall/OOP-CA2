/**
 * @author Pierre Siddall
 * The aim of this class is to hold all the attributes of a room that will be put into
 * the university's resource pool.
 * The constructor assigns the following to the class:
 *
 * The code of the room
 * The capacity of the room*/
public class Room {
    private String code;
    private int capacity;
    private static int count=100;

    /**
     * This method sets the value of the rooms code
     * by appending the value of the count attribute
     * to the string "IC". The count is then incremented by
     * a value of one to make the next rooms code unique*/
    public void setCode(){
        this.code="IC"+count;// Here  the code is formed by adding the count to "IC"
        count++;// Here the count for the room code is incremented
    }

    /**
     *
     * @return The rooms code
     */
    public String getCode(){
        return code;
    }

    /**
     * @param capacity The rooms maximum capacity (the amount of people the room can hold)
     * This method sets the capacity of the room
     * but also ensures that the room capacity
     * is not less than 1 by setting the capacity to 1
     * when the capacity passed is less than 1*/
    public void setCapacity(int capacity){
        if (capacity<1){//Here if the capacity parsed is lower than one the capacity automatically get set to one
            this.capacity=1;
        }else{
            this.capacity=capacity;
        }
    }

    /**
     *
     * @return The capacity of the room
     */
    public int getCapacity(){
        return capacity;
    }

    @Override
    public String toString(){
        return "|"+getCode()+"| capacity:"+getCapacity()+"|";
    }

    /**
     *
     * @param capacity
     *
     * This method is the constructor for the Room class which sets the capacity through
     * the parameter passed and sets the code using the code setter method
     */
    public Room(int capacity){
        setCode();
        setCapacity(capacity);
    }
}
