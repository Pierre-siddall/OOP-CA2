import java.util.ArrayList;
import java.util.Arrays;
/**
 * @author Pierre Siddall
 * This class is intended to hold the university resources
 * that will be used inside the booking system.
 * The university resources consist of
 * an ArrayList of assistants and
 * an ArrayList of rooms.*/
public class UniversityResources {

  private ArrayList<Assistant> assistants;
  private ArrayList<Room>rooms;

  /**
   * @param  assistants The array of assistants to be converted into an ArrayList
   * Sets the assistants array passed to an array list*/
  public void setAssistants(Assistant[] assistants){

      this.assistants=changeAssistantArrayToArrayList(assistants);
  }
  /**
   * @return The ArrayList of assistants*/
  public ArrayList<Assistant> getAssistants(){

      return assistants;
  }
  /**
   * @param rooms The array of rooms
   * Sets the array of rooms into an arraylist of rooms*/
  public void setRooms(Room[] rooms){

      this.rooms=changeRoomArrayToArrayList(rooms);
  }
  /**
   * @return The ArrayList of rooms*/
  public ArrayList<Room> getRooms(){

      return rooms;
  }
  /**
   * @return The array of assistants converted into an ArrayList
   * @param assistants This parameter is an array of assistants that is passed to convert the array into an ArrayList
   * This method converts an array of assistants into an ArrayList this method was implemented to make it easier to
   * pass values into the constructor of this class*/
  public ArrayList<Assistant> changeAssistantArrayToArrayList(Assistant[] assistants){
   ArrayList<Assistant> assistantsList=new ArrayList<Assistant>(Arrays.asList(assistants));
   return assistantsList;
  }
    /**
     * @return The array of rooms converted into an ArrayList
     * @param rooms This parameter is an array of rooms that is passed to convert the array into an ArrayList
     * This method converts an array of rooms into an ArrayList this method was implemented to make it easier to
     * pass values into the constructor of this class*/
  public ArrayList<Room> changeRoomArrayToArrayList(Room[] rooms){
      ArrayList<Room> roomsList=new ArrayList<Room>(Arrays.asList(rooms));
      return roomsList;
  }
/**
 * @param assistantToBeAdded This parameter holds the assistant that is going to be added to the ArrayList of assistants
 * This method adds a specified assistant to the university resources*/
  public void addAssistant(Assistant assistantToBeAdded){

      getAssistants().add(assistantToBeAdded); // adds to the assistants ArrayList
  }
  /**
   * @param roomToBeAdded This parameter holds the room that is going to be added to the ArrayList of rooms
   * This method adds a specified room to the university resources*/
  public void addRoom(Room roomToBeAdded){

      getRooms().add(roomToBeAdded);// adds to the Rooms ArrayList
  }
  /**
   * @param assistantToBeRemoved This parameter holds the assistant that is going to be removed from the ArrayList of assistants
   * This method removes a specified assistant from the university resources*/
  public void removeAssistant(Assistant assistantToBeRemoved){
      getAssistants().remove(assistantToBeRemoved); // removes from the assistants ArrayList
  }
  /**
   * @param roomToBeRemoved This parameter holds the room that is going to be removed from the ArrayList of rooms
   * This method removes a specified room from the university resources*/
  public void removeRoom(Room roomToBeRemoved){
      getRooms().remove(roomToBeRemoved); // removes from the assistants ArrayList
  }
  /**
   * @param Id This parameter holds the sequential ID of the room to be searched for
   * This method searches for a room with a given sequential ID and returns it if there was a match.
   * If there was no match the method returns a null*/
  public Room getRoomWithSequentialId(String Id){
      for (Room room : rooms){
          String checkId=room.getCode(); //Here the code of each room in the room array is compared to the search value
          if(checkId.equals(Id)){
              return room;
          }
      }return null;
  }
  /**
   * The constructor method*/
  public UniversityResources(Assistant[] assistants,Room[] rooms){
      setAssistants(assistants);
      setRooms(rooms);
  }
}
